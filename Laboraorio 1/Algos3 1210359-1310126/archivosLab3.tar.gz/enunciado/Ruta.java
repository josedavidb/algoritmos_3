public class Ruta
{
  public static void main (String[] args)
  {
    System.out.println("No hay nada implementado");
  }
}
